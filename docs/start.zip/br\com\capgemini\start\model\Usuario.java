package br.com.capgemini.start.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity(name="usuario")
public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	@NotBlank(message="obrigatório")
	@Size(min=0, max=100, message="máximo de 100 caracteres")
	private String nome;
	@Size(min=0, max=100, message="máximo de 100 caracteres")
	@Email(message="inválido")
	@Column(unique=true)
	private String email;
	@Enumerated(EnumType.STRING)
	private TipoUsuario tipo;

}
