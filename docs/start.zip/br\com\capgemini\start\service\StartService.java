package br.com.capgemini.start.service;

import br.com.capgemini.start.model.Start;
import br.com.capgemini.start.model.Usuario;
import br.com.capgemini.start.repository.StartRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StartService {

	@Autowired
	private StartRepository repository;

	public Start save(Start start) {
		return repository.save(start);
	}

	public Start update(Integer id, Start start) {
		return repository.save(start);
	}

	public void deleteById(Integer id) {
		repository.deleteById(id);
	}

	public List<Start> findAll() {
		return repository.findAll();
	}

	public Optional<Start> findById(Integer id) {
		return repository.findById(id);
	}

	public List<Start> findAllByStart(Usuario start){
		return repository.findAllByStart(start);
	}

}
