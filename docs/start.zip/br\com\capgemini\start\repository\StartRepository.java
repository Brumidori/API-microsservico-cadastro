package br.com.capgemini.start.repository;

import br.com.capgemini.start.model.Start;
import br.com.capgemini.start.model.Usuario;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StartRepository extends JpaRepository<Start, Integer> {

	List<Start> findAllByStart(Usuario start);

}
