package br.com.capgemini.start.controller;

import br.com.capgemini.start.model.Start;
import br.com.capgemini.start.model.Usuario;
import br.com.capgemini.start.service.StartService;
import java.util.List;
import javax.transaction.Transactional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("start")
public class StartController {

	@Autowired
	private StartService service;

	@PostMapping
	@Transactional
	@ResponseStatus(code = HttpStatus.CREATED)
	public Start post(@RequestBody @Valid Start start) {
		return service.save(start);
	}

	@PutMapping("id/{id}")
	@Transactional
	public Start put(@PathVariable("id") Integer id, @RequestBody @Valid Start start) {
		service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Start not found"));
		return service.update(id, start);
	}

	@GetMapping("id/{id}")
	@Transactional
	public Start get(@PathVariable("id") Integer id) {
		return service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Start not found"));
	}

	@DeleteMapping("id/{id}")
	@Transactional
	public void delete(@PathVariable("id") Integer id) {
		service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Start not found"));

		service.deleteById(id);
	}

	@GetMapping
	@Transactional
	public List<Start> get() {
		return service.findAll();
	}

	@GetMapping("start/{start}")
	@Transactional
	public List<Start> getByStart(@PathVariable("start") Usuario start) {
		return service.findAllByStart(start);
	}

}
