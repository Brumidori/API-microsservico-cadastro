package br.com.capgemini.start.model;

public enum TipoUsuario {
	ADM, COLABORADOR;
}
