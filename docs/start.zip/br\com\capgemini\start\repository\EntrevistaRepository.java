package br.com.capgemini.start.repository;

import br.com.capgemini.start.model.Entrevista;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntrevistaRepository extends JpaRepository<Entrevista, Integer> {

}
