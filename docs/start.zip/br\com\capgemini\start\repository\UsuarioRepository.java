package br.com.capgemini.start.repository;

import br.com.capgemini.start.model.Usuario;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

	List<Usuario> findAllByNome(String nome);

	List<Usuario> findAllByEmail(String email);

}
