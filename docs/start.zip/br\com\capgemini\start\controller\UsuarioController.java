package br.com.capgemini.start.controller;

import br.com.capgemini.start.model.Usuario;
import br.com.capgemini.start.service.UsuarioService;
import java.util.List;
import javax.transaction.Transactional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("usuario")
public class UsuarioController {

	@Autowired
	private UsuarioService service;

	@PostMapping
	@Transactional
	@ResponseStatus(code = HttpStatus.CREATED)
	public Usuario post(@RequestBody @Valid Usuario usuario) {
		return service.save(usuario);
	}

	@PutMapping("id/{id}")
	@Transactional
	public Usuario put(@PathVariable("id") Integer id, @RequestBody @Valid Usuario usuario) {
		service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario not found"));
		return service.update(id, usuario);
	}

	@GetMapping("id/{id}")
	@Transactional
	public Usuario get(@PathVariable("id") Integer id) {
		return service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario not found"));
	}

	@DeleteMapping("id/{id}")
	@Transactional
	public void delete(@PathVariable("id") Integer id) {
		service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario not found"));

		service.deleteById(id);
	}

	@GetMapping
	@Transactional
	public List<Usuario> get() {
		return service.findAll();
	}

	@GetMapping("nome/{nome}")
	@Transactional
	public List<Usuario> getByNome(@PathVariable("nome") String nome) {
		return service.findAllByNome(nome);
	}

	@GetMapping("email/{email}")
	@Transactional
	public List<Usuario> getByEmail(@PathVariable("email") String email) {
		return service.findAllByEmail(email);
	}

}
