package br.com.capgemini.start.controller;

import br.com.capgemini.start.model.Projeto;
import br.com.capgemini.start.model.Usuario;
import br.com.capgemini.start.service.ProjetoService;
import java.util.List;
import javax.transaction.Transactional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("projeto")
public class ProjetoController {

	@Autowired
	private ProjetoService service;

	@PostMapping
	@Transactional
	@ResponseStatus(code = HttpStatus.CREATED)
	public Projeto post(@RequestBody @Valid Projeto projeto) {
		return service.save(projeto);
	}

	@PutMapping("id/{id}")
	@Transactional
	public Projeto put(@PathVariable("id") Integer id, @RequestBody @Valid Projeto projeto) {
		service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Projeto not found"));
		return service.update(id, projeto);
	}

	@GetMapping("id/{id}")
	@Transactional
	public Projeto get(@PathVariable("id") Integer id) {
		return service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Projeto not found"));
	}

	@DeleteMapping("id/{id}")
	@Transactional
	public void delete(@PathVariable("id") Integer id) {
		service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Projeto not found"));

		service.deleteById(id);
	}

	@GetMapping
	@Transactional
	public List<Projeto> get() {
		return service.findAll();
	}

	@GetMapping("nome/{nome}")
	@Transactional
	public List<Projeto> getByNome(@PathVariable("nome") String nome) {
		return service.findAllByNome(nome);
	}

	@GetMapping("gestor/{gestor}")
	@Transactional
	public List<Projeto> getByGestor(@PathVariable("gestor") Usuario gestor) {
		return service.findAllByGestor(gestor);
	}

}
