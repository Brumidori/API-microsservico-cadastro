package br.com.capgemini.start.model;

public enum Farol {
	VERMELHO, AMARELO, VERDE, AZUL;
}
