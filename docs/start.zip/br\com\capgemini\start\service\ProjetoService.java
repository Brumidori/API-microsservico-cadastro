package br.com.capgemini.start.service;

import br.com.capgemini.start.model.Projeto;
import br.com.capgemini.start.model.Usuario;
import br.com.capgemini.start.repository.ProjetoRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProjetoService {

	@Autowired
	private ProjetoRepository repository;

	public Projeto save(Projeto projeto) {
		return repository.save(projeto);
	}

	public Projeto update(Integer id, Projeto projeto) {
		return repository.save(projeto);
	}

	public void deleteById(Integer id) {
		repository.deleteById(id);
	}

	public List<Projeto> findAll() {
		return repository.findAll();
	}

	public Optional<Projeto> findById(Integer id) {
		return repository.findById(id);
	}

	public List<Projeto> findAllByNome(String nome){
		return repository.findAllByNome(nome);
	}

	public List<Projeto> findAllByGestor(Usuario gestor){
		return repository.findAllByGestor(gestor);
	}

}
