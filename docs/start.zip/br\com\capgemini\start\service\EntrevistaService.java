package br.com.capgemini.start.service;

import br.com.capgemini.start.model.Entrevista;
import br.com.capgemini.start.repository.EntrevistaRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EntrevistaService {

	@Autowired
	private EntrevistaRepository repository;

	public Entrevista save(Entrevista entrevista) {
		return repository.save(entrevista);
	}

	public Entrevista update(Integer id, Entrevista entrevista) {
		return repository.save(entrevista);
	}

	public void deleteById(Integer id) {
		repository.deleteById(id);
	}

	public List<Entrevista> findAll() {
		return repository.findAll();
	}

	public Optional<Entrevista> findById(Integer id) {
		return repository.findById(id);
	}

}
