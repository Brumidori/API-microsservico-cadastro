package br.com.capgemini.start.controller;

import br.com.capgemini.start.model.Entrevista;
import br.com.capgemini.start.service.EntrevistaService;
import java.util.List;
import javax.transaction.Transactional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("entrevista")
public class EntrevistaController {

	@Autowired
	private EntrevistaService service;

	@PostMapping
	@Transactional
	@ResponseStatus(code = HttpStatus.CREATED)
	public Entrevista post(@RequestBody @Valid Entrevista entrevista) {
		return service.save(entrevista);
	}

	@PutMapping("id/{id}")
	@Transactional
	public Entrevista put(@PathVariable("id") Integer id, @RequestBody @Valid Entrevista entrevista) {
		service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Entrevista not found"));
		return service.update(id, entrevista);
	}

	@GetMapping("id/{id}")
	@Transactional
	public Entrevista get(@PathVariable("id") Integer id) {
		return service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Entrevista not found"));
	}

	@DeleteMapping("id/{id}")
	@Transactional
	public void delete(@PathVariable("id") Integer id) {
		service.findById(id)
			.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Entrevista not found"));

		service.deleteById(id);
	}

	@GetMapping
	@Transactional
	public List<Entrevista> get() {
		return service.findAll();
	}

}
