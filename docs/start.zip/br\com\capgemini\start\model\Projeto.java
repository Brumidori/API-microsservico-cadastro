package br.com.capgemini.start.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity(name="projeto")
public class Projeto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	@NotBlank(message="obrigatório")
	@Size(min=0, max=100, message="máximo de 100 caracteres")
	private String nome;
	private String cor;
	@ManyToOne
	private Usuario gestor;
	@ManyToMany
	private List<Usuario> proficionais;
	@ManyToMany
	private List<Start> starts;

}
