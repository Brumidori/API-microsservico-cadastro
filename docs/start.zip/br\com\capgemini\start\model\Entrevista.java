package br.com.capgemini.start.model;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Getter
@Setter
@ToString
@Entity(name="entrevista")
public class Entrevista implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	@DateTimeFormat(iso=ISO.DATE)
	private LocalDate data;
	@Size(min=0, max=200, message="máximo de 200 caracteres")
	private String parecer;
	@Size(min=0, max=200, message="máximo de 200 caracteres")
	private String notasJson;
	private Usuario proficional;

}
