package br.com.capgemini.start.service;

import br.com.capgemini.start.model.Avaliacao;
import br.com.capgemini.start.repository.AvaliacaoRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AvaliacaoService {

	@Autowired
	private AvaliacaoRepository repository;

	public Avaliacao save(Avaliacao avaliacao) {
		return repository.save(avaliacao);
	}

	public Avaliacao update(Integer id, Avaliacao avaliacao) {
		return repository.save(avaliacao);
	}

	public void deleteById(Integer id) {
		repository.deleteById(id);
	}

	public List<Avaliacao> findAll() {
		return repository.findAll();
	}

	public Optional<Avaliacao> findById(Integer id) {
		return repository.findById(id);
	}

}
